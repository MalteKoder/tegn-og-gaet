const socket = io();
let username = "";
let currentColor = '#000000';
let isEraser = false;
let penSize = 5;
let isDrawing = false;
let lastPosition = null;
let undoStack = [];
let redoStack = [];
let players = [];
let currentDrawer = null;
let currentWord = "";
let roundTime = 60;
let timerInterval = null;

// DOM elementer
const canvas = document.getElementById('drawingCanvas');
const ctx = canvas.getContext('2d');
const penSizeSlider = document.getElementById('penSizeSlider');
const penSizeDisplay = document.getElementById('penSizeDisplay');
const colorPicker = document.getElementById('colorPicker');
const eraserButton = document.getElementById('eraserButton');

// Initialiserer canvas
function initializeCanvas() {
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    saveCanvasState();
}

// Gem canvas-tilstand til undo-stakken
function saveCanvasState() {
    undoStack.push(canvas.toDataURL());
}

// Konverter museposition til canvas-koordinater
function getMousePos(e) {
    const rect = canvas.getBoundingClientRect();
    return {
        x: e.clientX - rect.left,
        y: e.clientY - rect.top
    };
}

// Join spil
function joinGame() {
    username = document.getElementById("usernameInput").value.trim();
    if (username) {
        document.getElementById("loginScreen").style.display = "none";
        document.getElementById("gameScreen").style.display = "block";
        socket.emit("join", username);
        initializeCanvas(); // Sørg for at canvas er initialiseret
        updateLeaderboard(); // Initialiser leaderboard
    }
}

// Opdaterer leaderboard med aktuelle spillere og point
function updateLeaderboard() {
    const leaderboardContent = document.getElementById('leaderboardContent');
    leaderboardContent.innerHTML = '';
    
    // Sorter spillere efter score (højeste først)
    const sortedPlayers = [...players].sort((a, b) => b.score - a.score);
    
    sortedPlayers.forEach(player => {
        const playerElement = document.createElement('div');
        playerElement.className = 'player-item';
        if (player.hasGuessed) {
            playerElement.classList.add('guessed');
        }
        if (player.id === currentDrawer) {
            playerElement.classList.add('drawing');
        }
        
        playerElement.innerHTML = `
            <span class="player-name">${player.username}</span>
            <span class="player-score">${player.score}</span>
        `;
        
        leaderboardContent.appendChild(playerElement);
    });
}

// Opdater spil-info (nuværende ord, tid, runde)
function updateGameInfo(gameData) {
    if (gameData.word) {
        // Skjul eller vis ord baseret på om du er tegner
        const wordDisplay = document.getElementById('currentWord');
        if (gameData.currentDrawer === socket.id) {
            wordDisplay.textContent = gameData.word;
        } else {
            // Vis skjult ord (understregninger)
            wordDisplay.textContent = gameData.word.replace(/[a-zA-Z]/g, '_ ').trim();
        }
    }
    
    if (gameData.roundInfo) {
        document.getElementById('roundInfo').textContent = `Runde: ${gameData.roundInfo}`;
    }
    
    if (gameData.timeLeft !== undefined) {
        updateTimer(gameData.timeLeft);
    }
}

// Opdater timeren
function updateTimer(seconds) {
    document.getElementById('timeLeft').textContent = `Tid: ${seconds}s`;
}

// Skift mellem normal pen og viskelæder
function setEraser() {
    isEraser = !isEraser;
    eraserButton.classList.toggle('active');
}

// Fortryd sidste handling
function undo() {
    if (undoStack.length > 1) {
        redoStack.push(undoStack.pop());
        const imgData = undoStack[undoStack.length - 1];
        const img = new Image();
        img.onload = function() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.drawImage(img, 0, 0);
        };
        img.src = imgData;
    }
}

// Gentag fortryd handling
function redo() {
    if (redoStack.length > 0) {
        const imgData = redoStack.pop();
        undoStack.push(imgData);
        const img = new Image();
        img.onload = function() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.drawImage(img, 0, 0);
        };
        img.src = imgData;
    }
}

// Håndter chat input
function handleChatInput(event) {
    if (event.key === 'Enter') {
        const input = document.getElementById('chatInput');
        const message = input.value.trim();
        if (message) {
            socket.emit('chatMessage', { username, message });
            input.value = '';
        }
    }
}

// Event listeners
window.addEventListener('load', function() {
    // Opdater pen-størrelse display
    penSizeDisplay.style.width = penSize + "px";
    penSizeDisplay.style.height = penSize + "px";
    
    // Lyt efter ændringer i pen-størrelse
    penSizeSlider.addEventListener('input', function() {
        penSize = parseInt(this.value);
        penSizeDisplay.style.width = penSize + "px";
        penSizeDisplay.style.height = penSize + "px";
    });
    
    // Lyt efter ændringer i pen-farve
    colorPicker.addEventListener('input', function() {
        currentColor = this.value;
    });
    
    // Canvas mouse events
    canvas.addEventListener('mousedown', startDrawing);
    canvas.addEventListener('mousemove', draw);
    canvas.addEventListener('mouseup', stopDrawing);
    canvas.addEventListener('mouseout', stopDrawing);
    
    // Touch events for mobile support
    canvas.addEventListener('touchstart', handleTouchStart);
    canvas.addEventListener('touchmove', handleTouchMove);
    canvas.addEventListener('touchend', stopDrawing);
});

// Start tegning
function startDrawing(e) {
    e.preventDefault();
    isDrawing = true;
    lastPosition = getMousePos(e);
    saveCanvasState();
    redoStack = []; // Ryd redo-stakken når man begynder at tegne
}

// Tegn
function draw(e) {
    if (!isDrawing) return;
    
    const currentPosition = getMousePos(e);
    
    ctx.beginPath();
    ctx.moveTo(lastPosition.x, lastPosition.y);
    ctx.lineTo(currentPosition.x, currentPosition.y);
    ctx.strokeStyle = isEraser ? "#ffffff" : currentColor;
    ctx.lineWidth = penSize;
    ctx.lineCap = 'round';
    ctx.stroke();
    
    // Send tegnedata til serveren
    socket.emit("draw", {
        x1: lastPosition.x,
        y1: lastPosition.y,
        x2: currentPosition.x,
        y2: currentPosition.y,
        color: ctx.strokeStyle,
        size: ctx.lineWidth
    });
    
    lastPosition = currentPosition;
}

// Stop tegning
function stopDrawing() {
    isDrawing = false;
    lastPosition = null;
}

// Touch event handlers
function handleTouchStart(e) {
    e.preventDefault();
    const touch = e.touches[0];
    const mouseEvent = new MouseEvent('mousedown', {
        clientX: touch.clientX,
        clientY: touch.clientY
    });
    startDrawing(mouseEvent);
}

function handleTouchMove(e) {
    e.preventDefault();
    if (!isDrawing) return;
    
    const touch = e.touches[0];
    const mouseEvent = new MouseEvent('mousemove', {
        clientX: touch.clientX,
        clientY: touch.clientY
    });
    draw(mouseEvent);
}

// Socket.io event listeners
socket.on('chatMessage', (data) => {
    const chatMessages = document.getElementById('chatMessages');
    const messageElement = document.createElement('div');
    messageElement.textContent = `${data.username}: ${data.message}`;
    
    // Hvis meddelelsen indeholder besked om gættet ord
    if (data.guessedCorrectly) {
        messageElement.style.color = '#4caf50';
        messageElement.style.fontWeight = 'bold';
        
        // Opdater spillerens status i leaderboard
        const playerIndex = players.findIndex(p => p.username === data.username);
        if (playerIndex !== -1) {
            players[playerIndex].hasGuessed = true;
            players[playerIndex].score += data.pointsAwarded || 100;
            updateLeaderboard();
        }
    }
    
    chatMessages.appendChild(messageElement);
    chatMessages.scrollTop = chatMessages.scrollHeight;
});

socket.on("draw", (data) => {
    ctx.beginPath();
    ctx.moveTo(data.x1, data.y1);
    ctx.lineTo(data.x2, data.y2);
    ctx.strokeStyle = data.color;
    ctx.lineWidth = data.size;
    ctx.lineCap = 'round';
    ctx.stroke();
});

// Modtag opdatering af spillerliste fra serveren
socket.on('updatePlayers', (playerData) => {
    players = playerData;
    updateLeaderboard();
});

// Modtag spillerens guess status
socket.on('playerGuessed', (data) => {
    const playerIndex = players.findIndex(p => p.id === data.playerId);
    if (playerIndex !== -1) {
        players[playerIndex].hasGuessed = true;
        players[playerIndex].score += data.pointsAwarded;
        updateLeaderboard();
    }
});

// Modtag information om ny runde
socket.on('newRound', (gameData) => {
    currentDrawer = gameData.currentDrawer;
    
    // Nulstil canvas hvis en ny runde starter
    if (gameData.resetCanvas) {
        ctx.fillStyle = "#ffffff";
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        undoStack = [];
        redoStack = [];
        saveCanvasState();
    }
    
    // Opdater spil-info
    updateGameInfo(gameData);
    
    // Opdater leaderboard for at markere den aktuelle tegner
    updateLeaderboard();
    
    // Nulstil guessed status for alle spillere
    players.forEach(player => player.hasGuessed = false);
    
    // Aktivér/deaktiver tegning baseret på om spilleren er den aktuelle tegner
    if (socket.id === gameData.currentDrawer) {
        // Aktivér tegneværktøjer
        canvas.style.pointerEvents = 'auto';
    } else {
        // Deaktiver tegneværktøjer for alle andre
        canvas.style.pointerEvents = 'none';
    }
});

// Modtag timer opdateringer
socket.on('timerUpdate', (data) => {
    updateTimer(data.timeLeft);
});

// Initialiser canvas ved page load
initializeCanvas();
