const express = require('express');
const http = require('http');
const socketIO = require('socket.io');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = socketIO(server);

// Serve statiske filer fra public mappen
app.use(express.static(path.join(__dirname, 'public')));

// Spillerdata
const rooms = {};
const words = ['hund', 'kat', 'hus', 'bil', 'tog', 'elefant', 'computer', 'pizza', 'chokolade', 'musik'];

// Funktion til at vælge et tilfældigt ord
function getRandomWord() {
  return words[Math.floor(Math.random() * words.length)];
}

// Funktion til at få spillerantal i et rum
function getPlayerCount(roomId) {
  return Object.keys(rooms[roomId]?.players || {}).length;
}

// Socket.IO forbindelser
io.on('connection', (socket) => {
  console.log(`Ny forbindelse: ${socket.id}`);
  
  // Når en spiller tilslutter spillet
  socket.on('join', (username) => {
    console.log(`Spiller ${username} (${socket.id}) tilslutter sig`);
    
    // Standard rumID (kan udvides til flere rum senere)
    const roomId = 'game';
    
    // Opret rummet hvis det ikke findes
    if (!rooms[roomId]) {
      rooms[roomId] = {
        players: {},
        currentDrawer: null,
        currentWord: null,
        timeLeft: 60,
        round: 1,
        maxRounds: 5,
        timer: null
      };
    }
    
    // Tilføj spilleren til rummet
    rooms[roomId].players[socket.id] = {
      id: socket.id,
      username: username,
      score: 0,
      hasGuessed: false
    };
    
    // Tilmeld socket til rummet
    socket.join(roomId);
    socket.roomId = roomId;
    
    // Fortæl alle i rummet om den nye spiller
    io.to(roomId).emit('playerJoined', rooms[roomId].players[socket.id]);
    
    // Send den opdaterede spillerliste til alle i rummet
    io.to(roomId).emit('updatePlayers', rooms[roomId].players);
    
    // Start runden hvis dette er den første spiller
    if (getPlayerCount(roomId) === 1) {
      rooms[roomId].currentDrawer = socket.id;
      startNewRound(roomId);
    } else {
      // Send den nuværende spilstatus til den nye spiller
      socket.emit('newRound', {
        currentDrawer: rooms[roomId].currentDrawer,
        word: rooms[roomId].currentWord,
        roundInfo: `${rooms[roomId].round}/${rooms[roomId].maxRounds}`,
        timeLeft: rooms[roomId].timeLeft,
        resetCanvas: true
      });
    }
  });
  
  // Når en spiller anmoder om spillerlisten
  socket.on('requestPlayers', () => {
    const roomId = socket.roomId;
    if (roomId && rooms[roomId]) {
      socket.emit('updatePlayers', rooms[roomId].players);
    }
  });
  
  // Når en spiller tegner noget
  socket.on('draw', (data) => {
    const roomId = socket.roomId;
    if (roomId) {
      // Tilføj afsender-id til tegnedata
      data.drawerId = socket.id;
      // Send til alle andre i rummet
      socket.to(roomId).emit('draw', data);
    }
  });
  
  // Når en spiller sender en chat-besked
  socket.on('chatMessage', (data) => {
    const roomId = socket.roomId;
    if (!roomId || !rooms[roomId]) return;
    
    // Tjek om spilleren gættede rigtigt
    if (rooms[roomId].currentWord && 
        data.message.toLowerCase() === rooms[roomId].currentWord.toLowerCase() && 
        socket.id !== rooms[roomId].currentDrawer &&
        !rooms[roomId].players[socket.id].hasGuessed) {
      
      // Beregn point baseret på tid
      const pointsAwarded = Math.max(10, Math.floor(rooms[roomId].timeLeft * 5));
      
      // Opdater spiller-status
      rooms[roomId].players[socket.id].hasGuessed = true;
      rooms[roomId].players[socket.id].score += pointsAwarded;
      
      // Giv point til tegneren også
      if (rooms[roomId].players[rooms[roomId].currentDrawer]) {
        rooms[roomId].players[rooms[roomId].currentDrawer].score += Math.floor(pointsAwarded / 4);
      }
      
      // Send besked om korrekt gæt
      io.to(roomId).emit('chatMessage', {
        username: "System",
        message: `${data.username} gættede ordet!`,
        guessedCorrectly: true
      });
      
      // Informer om spillerens gæt
      io.to(roomId).emit('playerGuessed', {
        playerId: socket.id,
        pointsAwarded: pointsAwarded
      });
      
      // Send opdateret spillerliste
      io.to(roomId).emit('updatePlayers', rooms[roomId].players);
      
      // Tjek om alle har gættet
      const players = rooms[roomId].players;
      const allGuessed = Object.keys(players).every(id => 
        id === rooms[roomId].currentDrawer || players[id].hasGuessed
      );
      
      if (allGuessed) {
        // Start en ny runde hvis alle har gættet
        clearTimeout(rooms[roomId].timer);
        setTimeout(() => startNewRound(roomId), 3000);
      }
    } else {
      // Normal chat-besked
      io.to(roomId).emit('chatMessage', data);
    }
  });
  
  // Når en spiller afbryder forbindelsen
  socket.on('disconnect', () => {
    const roomId = socket.roomId;
    if (roomId && rooms[roomId] && rooms[roomId].players[socket.id]) {
      // Fjern spilleren fra rummet
      delete rooms[roomId].players[socket.id];
      
      // Informer alle andre om afbrydelsen
      io.to(roomId).emit('playerLeft', socket.id);
      
      // Send opdateret spillerliste
      io.to(roomId).emit('updatePlayers', rooms[roomId].players);
      
      // Hvis rummet er tomt, fjern det
      if (getPlayerCount(roomId) === 0) {
        clearTimeout(rooms[roomId].timer);
        delete rooms[roomId];
        return;
      }
      
      // Hvis den nuværende tegner forlod spillet, start en ny runde
      if (socket.id === rooms[roomId].currentDrawer) {
        clearTimeout(rooms[roomId].timer);
        startNewRound(roomId);
      }
    }
  });
});

// Start en ny spillerunde
function startNewRound(roomId) {
  if (!rooms[roomId]) return;
  
  const playerIds = Object.keys(rooms[roomId].players);
  if (playerIds.length === 0) return;
  
  // Vælg den næste tegner
  let nextDrawerIndex = 0;
  if (rooms[roomId].currentDrawer) {
    const currentIndex = playerIds.indexOf(rooms[roomId].currentDrawer);
    nextDrawerIndex = (currentIndex + 1) % playerIds.length;
  }
  
  rooms[roomId].currentDrawer = playerIds[nextDrawerIndex];
  rooms[roomId].currentWord = getRandomWord();
  rooms[roomId].timeLeft = 60;
  
  // Nulstil alle gæt
  Object.keys(rooms[roomId].players).forEach(playerId => {
    rooms[roomId].players[playerId].hasGuessed = false;
  });
  
  // Send besked om ny runde til alle
  io.to(roomId).emit('newRound', {
    currentDrawer: rooms[roomId].currentDrawer,
    word: rooms[roomId].currentWord, // Vil blive vist eller skjult baseret på om spilleren er tegneren
    roundInfo: `${rooms[roomId].round}/${rooms[roomId].maxRounds}`,
    timeLeft: rooms[roomId].timeLeft,
    resetCanvas: true
  });
  
  // Send opdateret spillerliste
  io.to(roomId).emit('updatePlayers', rooms[roomId].players);
  
  // Start timer
  updateTimer(roomId);
}

// Opdater timer
function updateTimer(roomId) {
  if (!rooms[roomId]) return;
  
  rooms[roomId].timer = setTimeout(() => {
    rooms[roomId].timeLeft--;
    
    // Send timer-opdatering
    io.to(roomId).emit('timerUpdate', { timeLeft: rooms[roomId].timeLeft });
    
    if (rooms[roomId].timeLeft <= 0) {
      // Tiden er udløbet
      io.to(roomId).emit('chatMessage', {
        username: "System",
        message: `Tiden er udløbet! Ordet var: ${rooms[roomId].currentWord}`
      });
      
      // Start ny runde
      setTimeout(() => startNewRound(roomId), 3000);
    } else {
      // Fortsæt timeren
      updateTimer(roomId);
    }
  }, 1000);
}

// Start serveren
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Server kører på port ${PORT}`);
});