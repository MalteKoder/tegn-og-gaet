// Send automatisk en velkomstbesked til chatten ved join
    function sendWelcomeMessage() {
        console.log("Forsøger at sende velkomstbesked...");
        
        try {
            // Emitter chatMessage event med brugernavn
            if (socket && username) {
                socket.emit('chatMessage', { 
                    username: username, 
                    message: 'Hej alle! Jeg er lige tilsluttet spillet.' 
                });
            } else {
                console.warn("Socket eller username er ikke defineret endnu");
            }
        } catch (e) {
            console.error("Fejl under afsendelse af velkomstbesked:", e);
        }
        
        // Tilføj lokal velkomstbesked hvis server ikke svarer
        const chatMessages = document.getElementById('chatMessages');
        if (chatMessages && username) {
            const welcomeMsg = document.createElement('div');
            welcomeMsg.className = 'system-message';
            welcomeMsg.textContent = `${username} har tilsluttet sig spillet!`;
            chatMessages.appendChild(welcomeMsg);
            chatMessages.scrollTop = chatMessages.scrollHeight;
            
            // Tilføj spilleren til leaderboard baseret på velkomstbeskeden
            const playersList = Object.values(playersById || {});
            if (!playersList.some(p => p.username === username)) {
                const newId = 'welcome-' + Date.now();
                if (playersById) {
                    playersById[newId] = {
                        id: newId,
                        username: username,
                        score: 0,
                        hasGuessed: false
                    };
                    playerCount++;
                    updateLeaderboard();
                }
            }
        }
    }    // Tilføj en testchat-besked direkte efter DOM er indlæst
    setTimeout(() => {
        // Lav en lokal test-besked
        const chatMessages = document.getElementById('chatMessages');
        if (chatMessages) {
            const testMsg = document.createElement('div');
            testMsg.className = 'system-message';
            testMsg.textContent = 'Chatten er indlæst og klar til brug. Tryk Enter for at sende beskeder.';
            chatMessages.appendChild(testMsg);
            chatMessages.scrollTop = chatMessages.scrollHeight;
        }
        
        console.log("Chat test-besked tilføjet");
    }, 1500);// Vent på at DOM'en er fuldt indlæst
document.addEventListener('DOMContentLoaded', function() {
    // ----- VARIABLER -----
    const socket = io();
    let username = "";
    let currentColor = '#000000';
    let isEraser = false;
    let penSize = 5;
    let isDrawing = false;
    let lastPosition = null;
    let strokes = []; // Array til at gemme alle strøg
    let redoHistory = []; // Array til at gemme fortrydede strøg
    let currentStroke = null; // Det nuværende strøg under tegning
    
    // Globale variabler som alle funktioner kan tilgå
    window.playersById = {}; 
    window.playerCount = 0;
    window.socket = socket;
    
    let currentDrawer = null;
    let currentWord = "";
    let roundTime = 60;
    let timerInterval = null;

    // ----- DOM ELEMENTER -----
    const loginScreen = document.getElementById('loginScreen');
    const gameScreen = document.getElementById('gameScreen');
    const canvas = document.getElementById('drawingCanvas');
    const ctx = canvas ? canvas.getContext('2d') : null;
    const penSizeSlider = document.getElementById('penSizeSlider');
    const penSizeDisplay = document.getElementById('penSizeDisplay');
    const colorPicker = document.getElementById('colorPicker');
    const eraserButton = document.getElementById('eraserButton');
    const undoButton = document.getElementById('undoButton');
    const redoButton = document.getElementById('redoButton');
    const joinButton = document.getElementById('joinButton');
    const usernameInput = document.getElementById('usernameInput');
    const chatInput = document.getElementById('chatInput');
    const leaderboardContent = document.getElementById('leaderboardContent');

    // Tjek om nødvendige elementer eksisterer
    if (!canvas || !ctx) {
        console.error("Fejl: Canvas eller context kunne ikke initialiseres");
        return; // Stop udførelsen hvis canvas ikke er tilgængeligt
    }

    // ----- HJÆLPEFUNKTIONER -----
    
    // Få museposition relativt til canvas
    function getMousePos(e) {
        const rect = canvas.getBoundingClientRect();
        return {
            x: e.clientX - rect.left,
            y: e.clientY - rect.top
        };
    }

    // Opdater pensel-størrelse display
    function updatePenSizeDisplay() {
        if (penSizeDisplay) {
            penSizeDisplay.style.width = penSize + "px";
            penSizeDisplay.style.height = penSize + "px";
            penSizeDisplay.style.background = isEraser ? "#ffffff" : currentColor;
            penSizeDisplay.style.border = "1px solid #ccc";
            penSizeDisplay.style.borderRadius = "50%";
        }
    }

    // ----- CANVAS FUNKTIONER -----
    
    // Ryd canvas og initialiser tegnefladen
    function clearCanvas() {
        if (ctx) {
            ctx.fillStyle = "#ffffff";
            ctx.fillRect(0, 0, canvas.width, canvas.height);
        }
    }
    
    // Start tegning
    function startDrawing(e) {
        e.preventDefault();
        isDrawing = true;
        lastPosition = getMousePos(e);
        
        // Start et nyt strøg
        currentStroke = {
            points: [{ x: lastPosition.x, y: lastPosition.y }],
            color: isEraser ? "#ffffff" : currentColor,
            size: penSize,
            isEraser: isEraser
        };
        
        // Tegn en prik ved klikpunktet
        if (ctx) {
            ctx.beginPath();
            ctx.arc(lastPosition.x, lastPosition.y, penSize/2, 0, Math.PI * 2);
            ctx.fillStyle = currentStroke.color;
            ctx.fill();
        }
        
        console.log("Tegning startet");
    }
    
    // Tegn mens musen bevæges
    function draw(e) {
        if (!isDrawing || !lastPosition) return;
        
        const currentPos = getMousePos(e);
        
        // Tilføj punktet til det nuværende strøg
        if (currentStroke) {
            currentStroke.points.push({ x: currentPos.x, y: currentPos.y });
        }
        
        // Tegn linjen
        ctx.beginPath();
        ctx.moveTo(lastPosition.x, lastPosition.y);
        ctx.lineTo(currentPos.x, currentPos.y);
        ctx.strokeStyle = isEraser ? "#ffffff" : currentColor;
        ctx.lineWidth = penSize;
        ctx.lineCap = 'round';
        ctx.stroke();
        
        // Send tegnedata til serveren
        socket.emit("draw", {
            x1: lastPosition.x,
            y1: lastPosition.y,
            x2: currentPos.x,
            y2: currentPos.y,
            color: ctx.strokeStyle,
            size: ctx.lineWidth,
            drawerId: socket.id // Send tegneren's ID
        });
        
        // Opdater sidste position
        lastPosition = currentPos;
    }
    
    // Stop tegning
    function stopDrawing() {
        if (isDrawing && currentStroke) {
            // Gem strøget i historikken hvis det indeholder mindst 2 punkter
            if (currentStroke.points.length > 0) {
                strokes.push(currentStroke);
                redoHistory = []; // Ryd redo-historikken
                console.log("Strøg gemt, antal strøg: " + strokes.length);
            }
        }
        
        isDrawing = false;
        lastPosition = null;
        currentStroke = null;
    }

    // Genoptag tegning (når musen kommer tilbage på canvas med knappen trykket ned)
    function resumeDrawing(e) {
        if (e.buttons === 1) { // Venstre museknap stadig nede
            isDrawing = true;
            lastPosition = getMousePos(e);
            
            // Start et nyt strøg
            currentStroke = {
                points: [{ x: lastPosition.x, y: lastPosition.y }],
                color: isEraser ? "#ffffff" : currentColor,
                size: penSize,
                isEraser: isEraser
            };
            
            console.log("Tegning genoptaget");
        }
    }
    
    // Fortryd sidste strøg (undo)
    function undo() {
        if (strokes.length === 0) return;
        
        // Flyt sidste strøg til redo-historikken
        const lastStroke = strokes.pop();
        redoHistory.push(lastStroke);
        
        // Gentegn canvas
        redrawCanvas();
        console.log("Undo udført, antal strøg tilbage: " + strokes.length);
    }
    
    // Gendan sidste fortrydede strøg (redo)
    function redo() {
        if (redoHistory.length === 0) return;
        
        // Flyt sidste fortrydede strøg tilbage til strokes
        const redoneStroke = redoHistory.pop();
        strokes.push(redoneStroke);
        
        // Gentegn canvas
        redrawCanvas();
        console.log("Redo udført, antal strøg: " + strokes.length);
    }
    
    // Gentegn hele canvas baseret på stroke-historikken
    function redrawCanvas() {
        clearCanvas();
        
        // Tegn alle strøg
        strokes.forEach(stroke => {
            if (stroke.points.length < 2) {
                // For enkeltstående punkter
                if (stroke.points.length === 1) {
                    const point = stroke.points[0];
                    ctx.beginPath();
                    ctx.arc(point.x, point.y, stroke.size/2, 0, Math.PI * 2);
                    ctx.fillStyle = stroke.color;
                    ctx.fill();
                }
                return;
            }
            
            // For flere punkter, tegn linjer
            for (let i = 1; i < stroke.points.length; i++) {
                const p1 = stroke.points[i-1];
                const p2 = stroke.points[i];
                
                ctx.beginPath();
                ctx.moveTo(p1.x, p1.y);
                ctx.lineTo(p2.x, p2.y);
                ctx.strokeStyle = stroke.color;
                ctx.lineWidth = stroke.size;
                ctx.lineCap = 'round';
                ctx.stroke();
            }
        });
    }
    
    // Skift mellem normal pensel og viskelæder
    function setEraser() {
        isEraser = !isEraser;
        if (eraserButton) {
            eraserButton.classList.toggle('active');
        }
        updatePenSizeDisplay();
    }

    // ----- SPIL FUNKTIONER -----
    
    // Tilslut spillet
    function joinGame() {
        const inputUsername = usernameInput.value.trim();
        if (!inputUsername) return;
        
        username = inputUsername;
        console.log("Tilslutter spillet som: " + username);
        
        // Skift fra login til spil
        loginScreen.style.display = "none";
        gameScreen.style.display = "block";
        
        // Initialiser lokalt med et unikt ID for egen spiller
        const myId = 'local-' + Date.now();
        const localPlayer = {
            id: myId,
            username: username,
            score: 0,
            hasGuessed: false
        };
        
        // Tilføj egen spiller til spillerlisten
        window.playersById[myId] = localPlayer;
        window.playerCount = 1;
        
        updateLeaderboard();
        
        // Send join-anmodning til serveren
        socket.emit("join", username);
        
        // Bed om spillerlisten
        requestPlayerList();
        
        // Initialiser canvas
        clearCanvas();
        
        // Tillad tegning midlertidigt
        if (canvas) {
            canvas.style.pointerEvents = 'auto';
        }
        
        // Opdater penselstørrelsen visuelt
        updatePenSizeDisplay();
        
        // Vis instruktion til brugeren om at skrive "test" i chatten
        const chatMessages = document.getElementById('chatMessages');
        if (chatMessages) {
            const instructionMsg = document.createElement('div');
            instructionMsg.className = 'system-message';
            instructionMsg.style.fontWeight = 'bold';
            instructionMsg.textContent = 'Skriv "test" i chatten for at blive tilføjet til leaderboardet.';
            chatMessages.appendChild(instructionMsg);
            chatMessages.scrollTop = chatMessages.scrollHeight;
        }
    }
    
    // Anmod om spillerliste fra serveren
    function requestPlayerList() {
        socket.emit("requestPlayers");
        console.log("Anmodede om spillerliste fra serveren");
    }
    
    // Opdaterer leaderboard UI
    function updateLeaderboard() {
        if (!leaderboardContent) return;
        
        // Ryd leaderboard
        leaderboardContent.innerHTML = '';
        
        // Konverter spiller-objekt til array for sortering
        const playersList = Object.values(window.playersById || {});
        
        // Vis ventebesked hvis ingen spillere
        if (playersList.length === 0) {
            const emptyMsg = document.createElement('div');
            emptyMsg.className = 'empty-leaderboard';
            emptyMsg.textContent = 'Venter på spillere...';
            leaderboardContent.appendChild(emptyMsg);
            return;
        }
        
        // Sorter spillere efter score (højeste først)
        const sortedPlayers = [...playersList].sort((a, b) => b.score - a.score);
        
        // Debug log
        console.log(`Opdaterer leaderboard med ${playersList.length} spillere (forventet: ${window.playerCount}): ` + 
                     playersList.map(p => p.username).join(', '));
                     
        // Advarsel hvis antal spillere ikke matcher forventet antal
        if (playersList.length !== window.playerCount) {
            console.warn(`Advarsel: Antal spillere (${playersList.length}) matcher ikke forventet antal (${window.playerCount})`);
        }
        
        // Opret spiller-elementer
        sortedPlayers.forEach(player => {
            const playerEl = document.createElement('div');
            playerEl.className = 'player-item';
            
            // Tilføj tilstandsklasser
            if (player.hasGuessed) playerEl.classList.add('guessed');
            if (player.id === currentDrawer) playerEl.classList.add('drawing');
            if (player.username === username) playerEl.classList.add('self');
            
            playerEl.innerHTML = `
                <span class="player-name">${player.username}</span>
                <span class="player-score">${player.score}</span>
            `;
            
            leaderboardContent.appendChild(playerEl);
        });
    }
    
    // Opdater spil-info (ord, runde, tid)
    function updateGameInfo(gameData) {
        if (gameData.word) {
            const wordDisplay = document.getElementById('currentWord');
            if (wordDisplay) {
                if (gameData.currentDrawer === socket.id) {
                    wordDisplay.textContent = gameData.word;
                } else {
                    wordDisplay.textContent = gameData.word.replace(/[a-zA-Z]/g, '_ ').trim();
                }
            }
        }
        
        if (gameData.roundInfo) {
            const roundInfo = document.getElementById('roundInfo');
            if (roundInfo) {
                roundInfo.textContent = `Runde: ${gameData.roundInfo}`;
            }
        }
        
        if (gameData.timeLeft !== undefined) {
            updateTimer(gameData.timeLeft);
        }
    }
    
    // Opdater timer
    function updateTimer(seconds) {
        const timerEl = document.getElementById('timeLeft');
        if (timerEl) {
            timerEl.textContent = `Tid: ${seconds}s`;
        }
    }
    
    // Håndter chat-input
    function handleChatInput(e) {
        if (e.key === 'Enter') {
            const message = chatInput.value.trim();
            if (!message) return;
            
            console.log(`Sender chat-besked: ${message}`);
            
            // Emitter chatMessage event med brugernavn
            socket.emit('chatMessage', { 
                username: username, 
                message: message 
            });
            
            // Ryd input-feltet
            chatInput.value = '';
        }
    }
    
    // Flyt spil-info til bunden
    function moveGameInfoToBottom() {
        const gameInfoContainer = document.querySelector('.game-info');
        if (!gameInfoContainer) return;
        
        let bottomInfoContainer = document.querySelector('.bottom-game-info');
        if (!bottomInfoContainer) {
            bottomInfoContainer = document.createElement('div');
            bottomInfoContainer.className = 'bottom-game-info';
            
            const gameContainer = document.querySelector('.game-container');
            if (gameContainer && gameContainer.parentNode) {
                gameContainer.parentNode.insertBefore(bottomInfoContainer, gameContainer.nextSibling);
            }
        }
        
        bottomInfoContainer.appendChild(gameInfoContainer);
    }

    // ----- SOCKET.IO EVENT HANDLERS -----
    
    // Håndter når en anden spiller tegner noget
    socket.on("draw", (data) => {
        if (!ctx) return;
        
        // Tegn strøget
        ctx.beginPath();
        ctx.moveTo(data.x1, data.y1);
        ctx.lineTo(data.x2, data.y2);
        ctx.strokeStyle = data.color;
        ctx.lineWidth = data.size;
        ctx.lineCap = 'round';
        ctx.stroke();
        
        // Hvis der er et tegner-ID og det ikke er i vores liste, tilføj spilleren
        if (data.drawerId && !playersById[data.drawerId]) {
            const drawerName = `Spiller-${Object.keys(playersById).length + 1}`;
            playersById[data.drawerId] = {
                id: data.drawerId,
                username: drawerName,
                score: 0,
                hasGuessed: false
            };
            playerCount++;
            updateLeaderboard();
            console.log(`Tilføjede ukendt tegner med ID ${data.drawerId} som ${drawerName}`);
        }
    });
    
    // Modtag chat-besked
    socket.on('chatMessage', (data) => {
        const chatMessages = document.getElementById('chatMessages');
        if (!chatMessages) return;
        
        // Tilføj afsender til spillerliste hvis de ikke findes
        if (!players.some(p => p.username === data.username)) {
            players.push({
                id: 'chat-' + Date.now() + '-' + Math.random().toString(36).substr(2, 5),
                username: data.username,
                score: 0,
                hasGuessed: false
            });
            updateLeaderboard();
        }
        
        const msgEl = document.createElement('div');
        msgEl.textContent = `${data.username}: ${data.message}`;
        
        // Fremhæv korrekte gæt
        if (data.guessedCorrectly) {
            msgEl.style.color = '#4caf50';
            msgEl.style.fontWeight = 'bold';
            
            // Opdater spiller-status
            const playerIndex = players.findIndex(p => p.username === data.username);
            if (playerIndex !== -1) {
                players[playerIndex].hasGuessed = true;
                players[playerIndex].score += data.pointsAwarded || 100;
                updateLeaderboard();
            }
        }
        
        chatMessages.appendChild(msgEl);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    });
    
    // Modtag opdateret spillerliste
    socket.on('updatePlayers', (playerData) => {
        console.log("Modtog spillerliste fra server:", playerData);
        
        // Hvis spillerdata er et array, konverter til objekt
        if (Array.isArray(playerData)) {
            const newPlayersById = {};
            playerData.forEach(player => {
                newPlayersById[player.id] = player;
            });
            playersById = newPlayersById;
        } else {
            // Hvis det allerede er et objekt, brug det direkte
            playersById = playerData;
        }
        
        // Opdater spillerantal
        playerCount = Object.keys(playersById).length;
        
        // Sikre at egen spiller stadig er i listen
        let foundSelf = false;
        for (const id in playersById) {
            if (playersById[id].username === username) {
                foundSelf = true;
                break;
            }
        }
        
        // Tilføj egen spiller hvis manglende
        if (!foundSelf && username) {
            const myId = 'local-' + Date.now();
            playersById[myId] = {
                id: myId,
                username: username,
                score: 0,
                hasGuessed: false
            };
            playerCount++;
            console.log("Tilføjede egen spiller til listen, da den manglede");
        }
        
        updateLeaderboard();
    });
    
    // Modtag besked når ny spiller tilslutter
    socket.on('playerJoined', (player) => {
        console.log("Ny spiller tilsluttet:", player);
        
        // Tjek at playersById er initialiseret
        if (!playersById) {
            playersById = {};
            playerCount = 0;
        }
        
        // Tilføj spilleren til vores objekt hvis den ikke findes
        if (!playersById[player.id]) {
            playersById[player.id] = player;
            playerCount++;
            updateLeaderboard();
        } else {
            // Opdater eksisterende spiller
            playersById[player.id] = {...playersById[player.id], ...player};
            updateLeaderboard();
        }
        
        // Tilføj system-besked
        const chatMessages = document.getElementById('chatMessages');
        if (chatMessages) {
            const joinMsg = document.createElement('div');
            joinMsg.className = 'system-message';
            joinMsg.textContent = `${player.username} har tilsluttet sig spillet!`;
            chatMessages.appendChild(joinMsg);
            chatMessages.scrollTop = chatMessages.scrollHeight;
        }
    });
    
    // Modtag besked når spiller forlader
    socket.on('playerLeft', (playerId) => {
        if (playersById[playerId]) {
            const leavingPlayerName = playersById[playerId].username;
            
            // Vis afskeds-besked
            const chatMessages = document.getElementById('chatMessages');
            if (chatMessages) {
                const leaveMsg = document.createElement('div');
                leaveMsg.className = 'system-message';
                leaveMsg.textContent = `${leavingPlayerName} har forladt spillet.`;
                chatMessages.appendChild(leaveMsg);
                chatMessages.scrollTop = chatMessages.scrollHeight;
            }
            
            // Fjern spilleren fra objektet
            delete playersById[playerId];
            playerCount--;
            updateLeaderboard();
        }
    });
    
    // Modtag info om ny runde
    socket.on('newRound', (gameData) => {
        currentDrawer = gameData.currentDrawer;
        
        // Nulstil canvas hvis nødvendigt
        if (gameData.resetCanvas) {
            clearCanvas();
            strokes = [];
            redoHistory = [];
        }
        
        // Opdater spil-info
        updateGameInfo(gameData);
        updateLeaderboard();
        
        // Nulstil gæt
        players.forEach(player => player.hasGuessed = false);
        
        // Aktiver/deaktiver tegning
        if (canvas) {
            if (socket.id === gameData.currentDrawer) {
                canvas.style.pointerEvents = 'auto';
                console.log("Du er tegneren! Tegneværktøjer aktiveret.");
            } else {
                canvas.style.pointerEvents = 'none';
                console.log("Du er ikke tegneren. Tegneværktøjer deaktiveret.");
            }
        }
    });
    
    // Modtag timer-opdateringer
    socket.on('timerUpdate', (data) => {
        updateTimer(data.timeLeft);
    });
    
    // Modtag besked når spiller gætter korrekt
    socket.on('playerGuessed', (data) => {
        // Find spiller i vores objekt
        for (const id in window.playersById) {
            if (window.playersById[id].id === data.playerId) {
                window.playersById[id].hasGuessed = true;
                window.playersById[id].score += data.pointsAwarded;
                break;
            }
        }
        updateLeaderboard();
    });

    // ----- EVENT LISTENERS -----
    
    // Join knap
    if (joinButton) {
        joinButton.addEventListener('click', joinGame);
    }
    
    // Username input enter
    if (usernameInput) {
        usernameInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') joinGame();
        });
    }
    
    // Chat input
    if (chatInput) {
        chatInput.addEventListener('keypress', handleChatInput);
    }
    
    // Tegneværktøjer
    if (eraserButton) {
        eraserButton.addEventListener('click', setEraser);
    }
    
    if (undoButton) {
        undoButton.addEventListener('click', undo);
    }
    
    if (redoButton) {
        redoButton.addEventListener('click', redo);
    }
    
    // Pensel-størrelse slider
    if (penSizeSlider) {
        penSizeSlider.addEventListener('input', function() {
            penSize = parseInt(this.value);
            updatePenSizeDisplay();
        });
    }
    
    // Farve-vælger
    if (colorPicker) {
        colorPicker.addEventListener('input', function() {
            currentColor = this.value;
            if (!isEraser) {
                updatePenSizeDisplay();
            }
        });
    }
    
    // Canvas mouse events
    if (canvas) {
        canvas.addEventListener('mousedown', startDrawing);
        
        canvas.addEventListener('mousemove', draw);
        
        canvas.addEventListener('mouseup', stopDrawing);
        
        // Stop tegning når musen forlader canvas
        canvas.addEventListener('mouseleave', stopDrawing);
        
        // Genoptag tegning ved mouseenter hvis knappen stadig er trykket ned
        canvas.addEventListener('mouseenter', resumeDrawing);
        
        // Touch support
        canvas.addEventListener('touchstart', (e) => {
            e.preventDefault();
            const touch = e.touches[0];
            const mouseEvent = new MouseEvent('mousedown', {
                clientX: touch.clientX,
                clientY: touch.clientY
            });
            startDrawing(mouseEvent);
        });
        
        canvas.addEventListener('touchmove', (e) => {
            e.preventDefault();
            if (!isDrawing) return;
            
            const touch = e.touches[0];
            const mouseEvent = new MouseEvent('mousemove', {
                clientX: touch.clientX,
                clientY: touch.clientY
            });
            draw(mouseEvent);
        });
        
        canvas.addEventListener('touchend', () => {
            stopDrawing();
        });
    }
    
    // ----- INITIALIZATION -----
    
    // Initialiser visning af pensel-størrelse
    updatePenSizeDisplay();
    
    // Flyt game-info til bunden
    moveGameInfoToBottom();
    
    // Periodisk synkronisering af spillerliste
    setInterval(requestPlayerList, 10000);
    
    console.log("Spil initialiseret og klar!");
});